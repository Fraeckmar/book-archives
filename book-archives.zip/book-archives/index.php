<?php 
include_once('lib/includes/functions.php'); 
include_once('lib/includes/database.php'); 
include_once('lib/classes/book.php'); 
$Search = isset($_GET['s'])? $_GET['s'] : '';
$archive = isset($_GET['archive']) && $_GET['archive'] == 'yes'? true : false;
$book_fields = book_fields();
$book = new Book();
$book_records = $book->getRecords($Search, '', '', $archive);
$ConnDB = new ConnectDB();
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Book Archives</title>
		<link rel="stylesheet" href="lib/assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="lib/assets/css/custom-styles.css">
	</head>
	<body>	
		<div class="container">
			<div class="row">
				<!-- Search Form -->
				<div class="col-md-12 my-3">
					<form action="" method="GET">
						<div class="row">
							<div class="col-md-6">
								<div class="row">
									<div class="col-md-8">
										<div class="form-group mb-2">
											<input type="text" name="s" class="form-control w-100" placeholder="Eenter you keywords">
										</div>										
									</div>
									<div class="col-md-4">
										<button class="btn btn-primary mb-2 w-100">Search</button>
									</div>
								</div>
							</div>
						</div>
						
					</form>
				</div>
				<!-- Archives or Not -->
				<div class="col-md-12 mb-3">
					<div class="row">
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-6">
									<a href="?archive=no" id="recent-btn" class="btn btn-secondary w-100 active">Recent</a>
								</div>
								<div class="col-md-6">
									<a href="?archive=yes" id="archive-btn" class="btn btn-secondary w-100 active">Archive</a>
								</div>
							</div>
						</div>
						<div class="col-md-6 text-right">
							<button class="btn btn-success" data-toggle="modal" data-target="#addBookModal">+ Add</button>
						</div>
					</div>				
				</div>
			</div>
			<?php require_once('lib/templates/book-records.php')?>
		</div>
	<?php include_once('lib/templates/add-book.php'); ?>
	<?php include_once('lib/templates/update-book.php'); ?>
	<script src="lib/assets/js/jquery.min.js"></script>
	<script src="lib/assets/js/bootstrap.min.js"></script>
	<script src="lib/assets/js/custom-script.js"></script>
	</body>
</html>