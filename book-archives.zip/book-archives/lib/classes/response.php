<?php
class Response
{
	protected function responseError($message)
	{
		return [
			'status' => 'error',
			'message' => $message
		];
	}
	protected function responseSuccess($message)
	{
		return [
			'status' => 'success',
			'message' => $message
		];
	}
}