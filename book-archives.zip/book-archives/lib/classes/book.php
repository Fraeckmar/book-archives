<?php
$dirname = dirname(__DIR__);
require_once($dirname.'\classes\response.php');

class Book extends Response
{
	public $title;
	public $ISBN;
	public $author;
	public $publisher;
	public $year_published; 
	public $category;
	public $archive = false;

	public function setTitle($title)
	{
		$this->title = $title;
	}
	public function setISBN($ISBN)
	{
		$this->ISBN = $ISBN;
	}
	public function setAuthor($author)
	{
		$this->author = $author;
	}
	public function setPublisher($publisher)
	{
		$this->publisher = $publisher;
	}
	public function setPublishedYear($publishedYear)
	{
		$this->publishedYear = $publishedYear;
	}
	public function setCategory($category)
	{
		$this->category = $category;
	}
	public function setArchive($archive)
	{
		$this->archive = $archive;
	}
	private function setupDBConnection(){
		$server = "localhost";
		$username = "root";
		$password = "";
		$database = "book_archive";

		$mysqli = new mysqli($server, $username, $password, $database);
		return $mysqli;
	}

	/*
	 * Add new Book
	 */
	public function save()
	{
		$mysqli = $this->setupDBConnection();

		if ($mysqli->connect_error) {
			$message = 'Failed to connect: '.$mysqli->connect_error;
			return $this->responseError($message);
		}

		$sql = "INSERT INTO books (title, ISBN, author, publisher, year_published, category) VALUES ('{$this->title}', '{$this->ISBN}', '{$this->author}', '{$this->publisher}', {$this->year_published}, '{$this->category}')";

		$result = $mysqli->query($sql);
		$mysqli->close();

		echo $sql;

		if(!$result){
			return $this->responseError('Error in adding book.');
		}
		return $this->responseSuccess('Book added Successfuly.');
	}


	/*
	 * Update Book
	 */
	public function update($book_id)
	{
		$mysqli = $this->setupDBConnection();

		if ($mysqli->connect_error) {
			$message = 'Failed to connect: '.$mysqli->connect_error;
			return $this->responseError($message);
		}
		$sql = "UPDATE books 
			SET 
			title='{$this->title}', 
			ISBN = '{$this->ISBN}', 
			author = '{$this->author}',
			publisher = '{$this->publisher}', 
			year_published = {$this->year_published},
			category = '{$this->category}'
			WHERE id={$book_id}
		";
		$result = $mysqli->query($sql);
		if(!$result){
			return $this->responseError('Error in updating book.');
		}
		return $this->responseSuccess('Book updated Successfuly.');
	}

	public function putInArchive($book_id)
	{
		$mysqli = $this->setupDBConnection();
		$sql = "UPDATE books SET archive = true WHERE id={$book_id} ";
		$result = $mysqli->query($sql);
		if(!$result){
			return $this->responseError('Archive book error.');
		}
		return $this->responseSuccess('Archive book Successfuly');
	}

	public function removeInArchive($book_id)
	{
		$mysqli = $this->setupDBConnection();
		$sql = "UPDATE books SET archive = false WHERE id={$book_id} ";
		$result = $mysqli->query($sql);
		if(!$result){
			return $this->responseError('Removing book in archive error.');
		}
		return $this->responseSuccess('Removing book in archive Successfuly');
	}


	/*
	 * Update Book
	 */
	public function delete($book_id)
	{
		$mysqli = $this->setupDBConnection();

		if ($mysqli->connect_error) {
			$message = 'Failed to connect: '.$mysqli->connect_error;
			return $this->responseError($message);
		}

		$sql = "DELETE FROM books WHERE id={$book_id}";

		$result = $mysqli->query($sql);

		if(!$result){
			return $this->responseError('Error in deleting book.');
		}
		return $this->responseSuccess('Book deleted Successfuly.');
	}


	/*
	 * Get Book All Record
	 */
	public function getRecords($search='', $column='', $sort_by='', $archive=false)
	{
		$mysqli = $this->setupDBConnection();
		if ($mysqli->connect_error) {
			return [];
		}

		$sql = "SELECT * FROM books WHERE id IS NOT NULL";
		if(!empty($search)){
			$sql .= " AND '{$search}' IN (title, ISBN, author, publisher, year_published)";
		}
		if($archive){
			$sql .= " AND archive=true";
		}else{
			$sql .= " AND archive=false";
		}
		if(!empty($sort_by) && !empty($column)){
			$sql .= " ORDER BY {$column} {$sort_by}";
		}else{
			$sql .= " ORDER BY title ASC";
		}
		$result = $mysqli->query($sql);
		$records = [];

		if(!empty($result) && $result->num_rows > 0){
			while($row = $result->fetch_assoc()){
				$records[] = $row;
			}
		}
		$mysqli->close();
		return $records;
	}


	/*
	 * Get Book Single Record
	 */
	public function getSingleRecord($book_id)
	{
		$record = [];
		$mysqli = $this->setupDBConnection();
		if ($mysqli->connect_error) {
			return $record;
		}
		$sql = "SELECT * FROM books WHERE id = {$book_id}";
		$result = $mysqli->query($sql);

		if(!empty($result) && $result->num_rows > 0){
			$record = $result->fetch_assoc();
		}
		$mysqli->close();
		return $record;
	}
}