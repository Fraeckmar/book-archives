<table id="book-records-table" class="table table-striped table-bordered">
	<thead>
		<tr>
		  <?php foreach($book_fields as $key => $field): ?>
		  	<th scope="col" >
		  		<?php echo $field['label']; ?>
		  		<span class="arrow-container" data-col="<?php echo $key; ?>">
		  			<i class="arrow up" data-sort="DESC" title="Sort by Descending"></i>
		  			<i class="arrow down" data-sort="ASC" title="Sort by Ascending"></i>
		  		</span>
					</th>
		  <?php endforeach; ?>
		  <th>ARCHIVE</th>
		  <th></th>
		</tr>
	</thead>
	<tbody>
		<?php if(!empty($book_records)): ?>
			<?php foreach($book_records as $book): ?>
				<tr class="book-row">
					<?php foreach($book_fields as $key => $field): ?>
						<td><?php echo $book[$key]; ?></td>
					<?php endforeach; ?>
					<td>
						<?php if($archive): ?>
							<button class="btn btn-sm btn-info archive-book" data-type="remove" data-id="<?php echo $book['id']; ?>"></span>REMOVE</button>
						<?php else: ?>
							<button class="btn btn-sm btn-info archive-book" data-type="add" data-id="<?php echo $book['id']; ?>"></span>ADD</button>
						<?php endif; ?>
					</td>
					<td>
						<button class="btn btn-sm btn-info edit-book" data-toggle="modal" data-target="#updateBookModal" data-id="<?php echo $book['id']; ?>"></span>EDIT</button> <button class="btn btn-sm btn-danger delete-book" data-id="<?php echo $book['id']; ?>"></span>DEL</button>
					</td>
				</tr>
			<?php endforeach; ?>
		<?php endif; ?>
	</tbody>
</table>