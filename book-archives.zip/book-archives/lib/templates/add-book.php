<div class="modal fade" id="addBookModal" tabindex="-1" role="dialog" aria-labelledby="addBookModal" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <form id="add-book-form" action="" method="post">
        <div class="modal-header">
          <h5 class="modal-title">Add New Book</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">        
          <?php foreach($book_fields as $key => $field): ?>
            <?php $required = $field['required']? 'required' : '' ?>
            <div class="form-group">
              <label for="<?php echo $key ?>"><?php echo $field['label']; ?></label>
              <input type="text" name="<?php echo $key; ?>" id="<?php echo $key; ?>" class="form-control" <?php echo $required; ?>/>
            </div>
          <?php endforeach; ?>        
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Add</button>
        </div>
      </form>
    </div>
  </div>
</div>