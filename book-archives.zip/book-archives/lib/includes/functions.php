<?php
function book_fields(){
	return [
		'title' => [
			'label' => 'TITILE',
			'required' => true
		],
		'ISBN' => [
			'label' => 'ISBN',
			'required' => true
		],
		'author' => [
			'label' => 'AUTHOR', 
			'required' => true
		],
		'publisher' => [
			'label' => 'PUBLISHER',
			'required' => true
		],
		'year_published' => [
			'label' => 'YEAR PUBLISHED',
			'required' => true
		],
		'category' => [
			'label' => 'CATEGORY',
			'required' => true
		]
	];
}