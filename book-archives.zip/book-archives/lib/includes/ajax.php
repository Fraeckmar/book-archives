<?php
$dirname = dirname(__DIR__);
require_once($dirname.'\classes\book.php');
require_once($dirname.'\includes\functions.php');
include_once($dirname.'\includes\database.php');

if(isset($_POST['action'])){

	$action = $_POST['action'];

	// Add / Update Book
	if($action == 'add_book' || $action == 'update_book'){
		$ConnDB = new ConnectDB();
		if($ConnDB->table_book_exist()){
			if(isset($_POST['formData'])){
				$formData = $_POST['formData'];
				$type = $_POST['type'];
				$formattedData = [];

				if(!empty($formData)){
					foreach($formData as $data){
						$formattedData[$data['name']] = $data['value'];
					}
				}

				if(!empty($formattedData)){
					$newBook = new Book();
					foreach($formattedData as $fieldKkey => $data){
						$newBook->$fieldKkey = $data;
					}
					if($type == 'update'){
						// Update Book
						$result = $newBook->update($formattedData['id']);
					}else{
						// Add New Book
						$result = $newBook->save();
					}
					
					echo json_encode($result);
				}else{
					echo json_encode(['status'=>'error', 'message'=>'Empty data.']);
				}
				die();
			}
		}

	}

	// Dispaly / Update Book
	if($action == 'display_book' || $action == 'delete_book'){
		$ConnDB = new ConnectDB();
		if(isset($_POST['book_id'])){
			$type = isset($_POST['type'])? $_POST['type'] : '';
			$book_id = $_POST['book_id'];
			$mysqli = $ConnDB->buildConnection();
			$book = new Book();

			if($type == 'delete'){
				$result = $book->delete($book_id);		
			}else{
				$result = $book->getSingleRecord($book_id);
			}
			echo json_encode($result);	
			$mysqli->close();
			die();
		}
	}

	if($action == 'sort'){
		$sort_by 		= $_POST['sort_by'];
		$column 		= $_POST['column'];
		$archive 		= $_POST['archive'];
		$book_fields 	= book_fields();
		$book 			= new Book();
		$book_records 	= $book->getRecords('', $column, $sort_by);
		ob_start();
		require_once($dirname.'\templates\book-records.php');
		echo ob_get_clean();
		die();
	}
	if($action == 'archive_book') {
		$book_id 	= $_POST['book_id'];
		$type 		= $_POST['type'];
		if(!empty($book_id)){
			$book = new Book();
			if($type == 'add'){
				$book->putInArchive($book_id);
			}else{
				$book->removeInArchive($book_id);
			}
		}
	}
}