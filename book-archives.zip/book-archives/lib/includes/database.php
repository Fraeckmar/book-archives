<?php
class ConnectDB
{
	public function buildConnection()
	{
		$server = "localhost";
		$username = "root";
		$password = "";
		$database = "book_archive";

		// Create connection
		$mysqli = new mysqli($server, $username, $password, $database);
		return $mysqli;
	}
	private function create_book_table()
	{
		$result = false;
		$mysqli = $this->buildConnection();
		$sql = "CREATE TABLE books (
			id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			title VARCHAR(100) NOT NULL,
			ISBN VARCHAR(30) NOT NULL,
			author VARCHAR(30) NOT NULL,
			publisher VARCHAR(30),
			year_published INT(4),
			category VARCHAR(30),
			archive BOOLEAN DEFAULT false
		)";
		return $mysqli->query($sql);
	}
	public function table_book_exist()
	{
		$result = true;
		$mysqli = $this->buildConnection();
		$table = $mysqli->query("SHOW TABLES LIKE 'books'");
		if(!$table->num_rows){
			$result = $this->create_book_table();
		}
		$mysqli->close();
		return $result;
	}
}
